keywords = [
    "военные учения site:ria.ru",
    "тактические манёвры site:tass.ru",
    "армия РФ учения site:mil.ru",
    "боеготовность войск site:rg.ru",
    "военные сборы резервистов site:topwar.ru"
]